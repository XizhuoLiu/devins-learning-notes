from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_share = get_package_share_directory('uav_path_following')
    params = os.path.join(pkg_share, 'config', 'params.yaml')
    return LaunchDescription([
        Node(package='uav_path_following', executable='path_detector', name='path_detector', output='screen', parameters=[params]),
        Node(package='uav_path_following', executable='path_follower', name='path_follower', output='screen', parameters=[params])
    ])
