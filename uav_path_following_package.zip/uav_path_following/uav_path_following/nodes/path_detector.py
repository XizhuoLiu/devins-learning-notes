import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
from cv_bridge import CvBridge
import cv2
import numpy as np
from .fitters import (
    ls_fit, huber_fit, ransac_fit, eval_poly,
    bspline_fit, bspline_eval, ProMP1D
)

class PathDetector(Node):
    def __init__(self):
        super().__init__('path_detector')
        self.declare_parameters(namespace='',
            parameters=[
                ('image_topic', '/camera/image_raw'),
                ('debug_image_topic', '/path/debug_image'),
                ('path_topic', '/path/waypoints'),
                ('h_lower', 0), ('h_upper', 10),
                ('s_lower', 100), ('s_upper', 255),
                ('v_lower', 100), ('v_upper', 255),
                ('morph_kernel', 5),
                ('min_contour_area', 4000),
                ('fitter', 'ransac'),     # ls | huber | ransac | bspline | promp
                ('poly_order', 2),
            ]
        )
        img_topic = self.get_parameter('image_topic').get_parameter_value().string_value
        self.debug_topic = self.get_parameter('debug_image_topic').get_parameter_value().string_value
        self.path_topic = self.get_parameter('path_topic').get_parameter_value().string_value
        self.bridge = CvBridge()

        self.create_subscription(Image, img_topic, self.image_cb, 10)
        self.debug_pub = self.create_publisher(Image, self.debug_topic, 10)
        self.path_pub = self.create_publisher(Path, self.path_topic, 10)

        self.get_logger().info(f"PathDetector listening to {img_topic}")

    def image_cb(self, msg: Image):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        dbg = frame.copy()

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        h_lo = self.get_parameter('h_lower').value
        h_hi = self.get_parameter('h_upper').value
        s_lo = self.get_parameter('s_lower').value
        s_hi = self.get_parameter('s_upper').value
        v_lo = self.get_parameter('v_lower').value
        v_hi = self.get_parameter('v_upper').value

        # red hue wrap-around (0..10 and 170..180)
        mask1 = cv2.inRange(hsv, (h_lo, s_lo, v_lo), (h_hi, s_hi, v_hi))
        mask2 = cv2.inRange(hsv, (170, s_lo, v_lo), (180, s_hi, v_hi))
        mask = cv2.bitwise_or(mask1, mask2)

        ksize = self.get_parameter('morph_kernel').value
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (ksize, ksize))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)

        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
        if not contours:
            self.debug_pub.publish(self.bridge.cv2_to_imgmsg(dbg, encoding='bgr8'))
            return

        cnt = max(contours, key=cv2.contourArea)
        if cv2.contourArea(cnt) < self.get_parameter('min_contour_area').value:
            self.debug_pub.publish(self.bridge.cv2_to_imgmsg(dbg, encoding='bgr8'))
            return

        pts = cnt.reshape(-1, 2)
        pts = pts[pts[:,0].argsort()]
        x = pts[:,0].astype(np.float64)
        y = pts[:,1].astype(np.float64)

        fitter = self.get_parameter('fitter').get_parameter_value().string_value
        num_wp = 30

        if fitter in ('ls', 'huber', 'ransac'):
            order = int(self.get_parameter('poly_order').value)
            if fitter == 'ls':
                beta = ls_fit(x, y, order)
            elif fitter == 'huber':
                beta = huber_fit(x, y, order)
            else:
                beta = ransac_fit(x, y, order)
            xs = np.linspace(x.min(), x.max(), num_wp)
            ys = eval_poly(beta, xs)
            uncert = None

        elif fitter == 'bspline':
            tck = bspline_fit(x, y, smooth=3.0, k=3)
            xs = np.linspace(x.min(), x.max(), num_wp)
            ys = bspline_eval(tck, xs)
            uncert = None

        elif fitter == 'promp':
            # phase variable s in [0,1] along sorted x
            s = (x - x.min()) / max(1e-6, (x.max() - x.min()))
            promp = ProMP1D(n_basis=12, l2=1e-3)
            promp.fit_demo(s, y)
            s_query = np.linspace(0.0, 1.0, num_wp)
            xs = x.min() + s_query * (x.max() - x.min())
            ys, var = promp.mean_and_var(s_query)
            uncert = np.sqrt(np.maximum(var, 0.0))  # std

        else:
            # fallback
            order = 2
            beta = ls_fit(x, y, order)
            xs = np.linspace(x.min(), x.max(), num_wp)
            ys = eval_poly(beta, xs)
            uncert = None

        # draw fitted path
        for i in range(num_wp-1):
            p1 = tuple(np.int32([xs[i], ys[i]]))
            p2 = tuple(np.int32([xs[i+1], ys[i+1]]))
            cv2.line(dbg, p1, p2, (0,255,0), 2)

        # draw contour
        cv2.drawContours(dbg, [cnt], -1, (255,0,0), 2)

        # draw ProMP uncertainty band (±2σ) if available
        if uncert is not None:
            for i in range(num_wp-1):
                y_low1 = int(ys[i] - 2*uncert[i])
                y_high1 = int(ys[i] + 2*uncert[i])
                y_low2 = int(ys[i+1] - 2*uncert[i+1])
                y_high2 = int(ys[i+1] + 2*uncert[i+1])
                cv2.line(dbg, (int(xs[i]), y_low1), (int(xs[i+1]), y_low2), (0,200,200), 1)
                cv2.line(dbg, (int(xs[i]), y_high1), (int(xs[i+1]), y_high2), (0,200,200), 1)

        # publish debug image
        self.debug_pub.publish(self.bridge.cv2_to_imgmsg(dbg, encoding='bgr8'))

        # publish path
        path = Path()
        path.header = msg.header
        path.header.frame_id = 'camera_image'
        for (px, py) in zip(xs, ys):
            ps = PoseStamped()
            ps.header = msg.header
            ps.header.frame_id = 'camera_image'
            ps.pose.position.x = float(px)
            ps.pose.position.y = float(py)
            ps.pose.position.z = 0.0
            ps.pose.orientation.w = 1.0
            path.poses.append(ps)
        self.path_pub.publish(path)

def main(args=None):
    rclpy.init(args=args)
    node = PathDetector()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
