import numpy as np
from scipy.interpolate import splrep, splev

def design_matrix(x, order=2):
    x = np.asarray(x).reshape(-1, 1)
    return np.hstack([x**i for i in range(order+1)])

def ls_fit(x, y, order=2):
    X = design_matrix(x, order)
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    return beta

def huber_weights(residuals, delta=1.345):
    r = np.abs(residuals)
    w = np.ones_like(r)
    mask = r > delta
    w[mask] = delta / r[mask]
    return w

def huber_fit(x, y, order=2, delta=1.345, max_iter=50, eps=1e-6):
    X = design_matrix(x, order)
    beta = ls_fit(x, y, order)
    for _ in range(max_iter):
        y_pred = X @ beta
        r = y - y_pred
        w = huber_weights(r, delta)
        W = np.diag(w)
        beta_new, *_ = np.linalg.lstsq(W @ X, W @ y, rcond=None)
        if np.linalg.norm(beta_new - beta) < eps:
            break
        beta = beta_new
    return beta

def ransac_fit(x, y, order=2, max_trials=200, inlier_thresh=3.0, min_inliers=20):
    x = np.asarray(x); y = np.asarray(y)
    n = len(x)
    if n < order+1:
        return ls_fit(x, y, order)
    best_beta = None
    best_inliers = []
    rng = np.random.default_rng()
    for _ in range(max_trials):
        idx = rng.choice(n, size=order+1, replace=False)
        beta = ls_fit(x[idx], y[idx], order)
        y_pred = design_matrix(x, order) @ beta
        residuals = np.abs(y - y_pred)
        inliers = np.where(residuals < inlier_thresh)[0]
        if len(inliers) > len(best_inliers):
            best_inliers = inliers
            best_beta = beta
            if len(inliers) >= max(min_inliers, int(0.6*n)):
                best_beta = ls_fit(x[inliers], y[inliers], order)
    if best_beta is None:
        best_beta = ls_fit(x, y, order)
    return best_beta

def eval_poly(beta, x):
    X = design_matrix(x, len(beta)-1)
    return X @ beta

# ----------------- B-Spline fitting -----------------
def bspline_fit(x, y, smooth=3.0, k=3):
    """Fit a univariate B-spline y(x). Returns tck for splev."""
    # enforce strictly increasing x for splrep
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    order = np.argsort(x)
    x = x[order]; y = y[order]
    # s is smoothing factor; k is spline order (cubic=3)
    tck = splrep(x, y, s=smooth, k=k)
    return tck

def bspline_eval(tck, xq):
    return splev(xq, tck)

# ----------------- Minimal ProMP (RBF basis) -----------------
def _rbf_basis(s, centers, width):
    s = s.reshape(-1,1)
    return np.exp(-0.5 * ((s - centers.reshape(1,-1))**2) / (width**2))

class ProMP1D:
    """A minimalist 1D ProMP along a phase variable s in [0,1].
    We fit y(s) ~ Phi(s) w, with w ~ N(mu_w, Sigma_w).
    Since we may have only one demo here, we estimate mu_w via ridge regression
    and Sigma_w as diagonal from residual variance.
    """
    def __init__(self, n_basis=10, l2=1e-3):
        self.n_basis = n_basis
        self.l2 = l2
        self.centers = np.linspace(0, 1, n_basis)
        # heuristic width so that bases overlap
        self.width = 1.0 / (n_basis * 2.0)
        self.mu_w = None
        self.Sigma_w = None

    def _Phi(self, s):
        Phi = _rbf_basis(s, self.centers, self.width)
        # normalize across basis
        Phi_sum = np.sum(Phi, axis=1, keepdims=True) + 1e-8
        return Phi / Phi_sum

    def fit_demo(self, s, y):
        s = np.asarray(s, dtype=float)
        y = np.asarray(y, dtype=float)
        Phi = self._Phi(s)
        # ridge regression
        A = Phi.T @ Phi + self.l2 * np.eye(self.n_basis)
        b = Phi.T @ y
        self.mu_w = np.linalg.solve(A, b)
        # residual variance -> diagonal Sigma_w
        y_hat = Phi @ self.mu_w
        res = y - y_hat
        sigma2 = np.var(res) if res.size > 1 else 1e-3
        self.Sigma_w = sigma2 * np.eye(self.n_basis)

    def mean_and_var(self, s_query):
        s_query = np.asarray(s_query, dtype=float)
        Phi_q = self._Phi(s_query)
        mu_y = Phi_q @ self.mu_w
        # var_y = Phi_q * Sigma_w * Phi_q^T (diagonal shortcut)
        var_y = np.sum((Phi_q @ self.Sigma_w) * Phi_q, axis=1)
        return mu_y, var_y
