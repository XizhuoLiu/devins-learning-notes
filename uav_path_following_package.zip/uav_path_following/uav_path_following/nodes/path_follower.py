import rclpy
from rclpy.node import Node
from nav_msgs.msg import Path
from geometry_msgs.msg import Twist

import numpy as np

class PathFollower(Node):
    def __init__(self):
        super().__init__('path_follower')
        self.declare_parameters(namespace='',
            parameters=[
                ('path_topic', '/path/waypoints'),
            ]
        )
        path_topic = self.get_parameter('path_topic').get_parameter_value().string_value
        self.create_subscription(Path, path_topic, self.path_cb, 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.get_logger().info(f"PathFollower subscribing to {path_topic}")

    def path_cb(self, msg: Path):
        if not msg.poses:
            return
        target = msg.poses[min(5, len(msg.poses)-1)].pose.position
        err_x = target.x
        cmd = Twist()
        cmd.linear.x = 0.2
        cmd.angular.z = - (err_x - 320.0) / 320.0 * 0.5
        self.cmd_pub.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = PathFollower()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
