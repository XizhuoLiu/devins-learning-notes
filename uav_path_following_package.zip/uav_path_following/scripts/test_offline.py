import argparse, cv2, numpy as np
from uav_path_following.nodes.fitters import (
    ls_fit, huber_fit, ransac_fit, eval_poly,
    bspline_fit, bspline_eval, ProMP1D
)

def detect_and_fit(img, fitter='ransac', order=2, h_range=(0,10), s_range=(100,255), v_range=(100,255),
                   morph_kernel=5, min_area=4000):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, (h_range[0], s_range[0], v_range[0]), (h_range[1], s_range[1], v_range[1]))
    mask2 = cv2.inRange(hsv, (170, s_range[0], v_range[0]), (180, s_range[1], v_range[1]))
    mask = cv2.bitwise_or(mask1, mask2)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (morph_kernel, morph_kernel))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    vis = img.copy()
    if not contours:
        return vis
    cnt = max(contours, key=cv2.contourArea)
    if cv2.contourArea(cnt) < min_area:
        return vis
    pts = cnt.reshape(-1, 2)
    pts = pts[pts[:,0].argsort()]
    x = pts[:,0].astype(np.float64)
    y = pts[:,1].astype(np.float64)

    num_wp = 30
    if fitter == 'ls':
        beta = ls_fit(x, y, order)
        xs = np.linspace(x.min(), x.max(), num_wp)
        ys = eval_poly(beta, xs)
        uncert = None
    elif fitter == 'huber':
        beta = huber_fit(x, y, order)
        xs = np.linspace(x.min(), x.max(), num_wp)
        ys = eval_poly(beta, xs)
        uncert = None
    elif fitter == 'ransac':
        beta = ransac_fit(x, y, order)
        xs = np.linspace(x.min(), x.max(), num_wp)
        ys = eval_poly(beta, xs)
        uncert = None
    elif fitter == 'bspline':
        tck = bspline_fit(x, y, smooth=3.0, k=3)
        xs = np.linspace(x.min(), x.max(), num_wp)
        ys = bspline_eval(tck, xs)
        uncert = None
    elif fitter == 'promp':
        s = (x - x.min()) / max(1e-6, (x.max() - x.min()))
        promp = ProMP1D(n_basis=12, l2=1e-3)
        promp.fit_demo(s, y)
        s_query = np.linspace(0.0, 1.0, num_wp)
        xs = x.min() + s_query * (x.max() - x.min())
        ys, var = promp.mean_and_var(s_query)
        uncert = np.sqrt(np.maximum(var, 0.0))
    else:
        beta = ls_fit(x, y, 2)
        xs = np.linspace(x.min(), x.max(), num_wp)
        ys = eval_poly(beta, xs)
        uncert = None

    # draw results
    for i in range(len(xs)-1):
        p1 = (int(xs[i]), int(ys[i]))
        p2 = (int(xs[i+1]), int(ys[i+1]))
        cv2.line(vis, p1, p2, (0,255,0), 2)
    cv2.drawContours(vis, [cnt], -1, (255,0,0), 2)

    if uncert is not None:
        for i in range(len(xs)-1):
            y_low1 = int(ys[i] - 2*uncert[i])
            y_high1 = int(ys[i] + 2*uncert[i])
            y_low2 = int(ys[i+1] - 2*uncert[i+1])
            y_high2 = int(ys[i+1] + 2*uncert[i+1])
            cv2.line(vis, (int(xs[i]), y_low1), (int(xs[i+1]), y_low2), (0,200,200), 1)
            cv2.line(vis, (int(xs[i]), y_high1), (int(xs[i+1]), y_high2), (0,200,200), 1)

    return vis

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--image', required=True)
    ap.add_argument('--fitter', default='ransac', choices=['ls','huber','ransac','bspline','promp'])
    args = ap.parse_args()
    img = cv2.imread(args.image)
    vis = detect_and_fit(img, fitter=args.fitter)
    cv2.imwrite('output_vis.jpg', vis)
    print('Saved output_vis.jpg')
