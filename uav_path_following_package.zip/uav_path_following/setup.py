from setuptools import setup

setup(name='uav_path_following', version='0.1.0', packages=['uav_path_following'])
